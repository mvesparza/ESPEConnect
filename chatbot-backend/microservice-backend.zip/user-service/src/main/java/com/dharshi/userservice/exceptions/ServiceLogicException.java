package com.dharshi.userservice.exceptions;

public class ServiceLogicException extends Exception{
    public ServiceLogicException(String message) {
        super(message);
    }
}

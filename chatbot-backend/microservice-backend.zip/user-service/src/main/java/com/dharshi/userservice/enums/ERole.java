package com.dharshi.userservice.enums;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
